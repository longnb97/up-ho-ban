import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-wizard',
  templateUrl: './wizard.component.html',
  styleUrls: ['./wizard.component.scss']
})
export class WizardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
